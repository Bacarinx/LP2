﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Prova
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            lstBoxInformacoes.Items.Clear();

            double[,] valores = new double[3, 4];
            double[] valoresMeses = new double[3];
            double valorTotal = 0;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    string aux = Interaction.InputBox($"Digíte os valores da venda do mês {i + 1} semana {j + 1}.", "Entrada de Dados");

                    if (aux == "") return;

                    if (!Double.TryParse(aux, out valores[i, j]) || valores[i, j] < 0)
                    {
                        MessageBox.Show("Digite um valor válido e tente novamente.");
                        j--;
                    }
                    else
                    {
                        valoresMeses[i] += valores[i, j];
                    }
                }
                valorTotal += valoresMeses[i];
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    lstBoxInformacoes.Items.Add($"Total do mês {i + 1} Semana {j + 1}: {valores[i, j].ToString("N2")}");
                }

                lstBoxInformacoes.Items.Add($">> Total do Mês: {valoresMeses[i].ToString("N2")}");
                lstBoxInformacoes.Items.Add("---------------");
            }

            lstBoxInformacoes.Items.Add($">> Total Geral: {valorTotal.ToString("N2")}");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            lstBoxInformacoes.Items.Clear();
        }
    }
}
